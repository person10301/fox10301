+++
title = "About me"
template = "page.html"
+++
## person10301
* **Pronouns**: he/him он/его
* **Languages**: Русский (родной), English (probably not)

Здесь должен быть текст о себе...

Советую загляну к [@AuroraMusic](https://www.youtube.com/@AuroraMusic)

## Contact

* **[Telegram](https://t.me/fox10301)**