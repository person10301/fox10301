#!/bin/sh

cd "$(dirname "$0")"
date '+%F' > templates/partials/footerdate.html
git rev-parse --short HEAD > templates/partials/footergit.html
cd -
